﻿

public class EmotionRequest
{
    public string url { get; set; }
}
