﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Demo1._2
{
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Text;

    using Windows.UI.Xaml.Media.Imaging;

    using Demo1._2.Model;

    using Newtonsoft.Json;

    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void AnalyzeThis()
        {
            var client = new HttpClient();
            // Request headers
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "COPY-KEY-HERE");

            // Request parameters
            var uri = "https://westus.api.cognitive.microsoft.com/linguistics/v1.0/analyze?";
            LinguisticRequest request = new LinguisticRequest();
            request.language = "en";
            request.analyzerIds = new string[] { "22a6b758-420f-4745-8a3c-46835a67c0d2" };
            request.text = this.requestText.Text;
            byte[] byteData = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request));

            using (var content = new ByteArrayContent(byteData))
            {
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                var response = await client.PostAsync(uri, content);
                var json = await response.Content.ReadAsStringAsync();
                List<LinguisticResponse> responseList = JsonConvert.DeserializeObject<List<LinguisticResponse>>(json);
                this.resultText.Text = responseList[0].result[0];
            }


        }

        private void Send_OnClick(object sender, RoutedEventArgs e)
        {
            this.AnalyzeThis();
        }
    }
}
