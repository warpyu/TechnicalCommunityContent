﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Demo1._2.Model
{
    using Newtonsoft.Json;

    public class LinguisticResponse
    {
        public string analyzerId { get; set; }
        public List<string> result { get; set; }
    }
}
