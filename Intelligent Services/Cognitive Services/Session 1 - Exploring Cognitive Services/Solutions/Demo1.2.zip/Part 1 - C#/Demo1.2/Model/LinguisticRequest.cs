﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1._2.Model
{
    public class LinguisticRequest
    {
        public string language { get; set; }
        public string[] analyzerIds { get; set; }
        public string text { get; set; }
    }

}
