﻿//*******************************************************************
//To run from command prompt install Node.js for Windows from:
//  https://nodejs.org/en/
//
//after installing Node, install the following:
//
//REQUEST:
//  npm install request 
//PROMPT:
//  npm install prompt 
//*******************************************************************

//*******************************************************************
//To run this script from Command Prompt:
//  node app.js
//*******************************************************************

//*******************************************************************
//To debug using VS:
//Install Node Tools for VS (NTVS) from:
//  https://github.com/Microsoft/nodejstools/releases/tag/v1.2.RTW
//
// EITHER
//
// 1. Start as a solution.
//
// 2. Debug as normal after running in VS
//
// OR
//
// 1. at Command Prompt:
//      node RemoteDebug.js cognitiveSample.js
//
// 2. In Visual Studio, select Debug > Attach to Process
//
// 3. Select Node.js remote debugging for Transport
//
// 4. Enter localhost:5859 for Qualifier
//
// 5. Click Attach
//
//    This will put Visual Studio in debugging mode which you 
//    can set a breakpoint, do step-in/step-out, very same 
//    experience when you use VS to debug .NET app.
//*******************************************************************


//Allows for Prompting the user for input.
var prompt = require('prompt'), arr = [];
// create http request client to consume our REST API call.
var request = require('request')

// Cognitive REST API URL
url = "https://westus.api.cognitive.microsoft.com/linguistics/v1.0/analyze";

//OCP API Key
apiKey = "COPY-KEY-HERE";


//Using this schema allows us to create a 
//custom prompt and easily retrieve the
//text response.
//
//<description>
//  prompt that the user sees 
//</description>
//
//<pattern> 
//  used allows for regular sentence 
//  input with numbers and punctuation.
//</pattern>
//
//<message>
//  error message for text that doesn't 
//  pass the pattern test.
//</message>
var promptSchema = {
  properties: {
    analyze: {
      description: "Text to analyze (letters, spaces, numbers and punctuation only)",
      pattern: /[A-Za-z0-9 _.,!"'/$]*/,
      message: 'Text to analyze must be letters, spaces, numbers and punctuation only',
      required: true
    }
  }
  };

//Functions

//Gets the initial input from 
//the user.
function getInput() {
  prompt.get(promptSchema, function (err, result) {
    if (err) done();
    else {
      //success!  call the API
      //and analyze this text.
      callApi(result.analyze);
    }
  })
}

function callApi(analyzeText) {
  // JSON to be passed to the Microsoft Cognitive API
  var postData = {
    "language": "en",
    "analyzerIds": ["22a6b758-420f-4745-8a3c-46835a67c0d2"],
    "text": analyzeText
  }

  //request options object
  var options = {
    method: 'post',
    body: postData, // Javascript object containing data to post
    json: true,
    url: url,
    headers: {
      "content-type": "application/json",
      "Ocp-Apim-Subscription-Key": apiKey
    }
  }

  //Actual request call
  request(options, function (err, res, body) {
    if (err) {
      //oops! something went wrong,
      //tell the user what happened.
      console.log('Error :', err)
      return
    }
    //It worked, display the results.
    console.log(' Body :', body)

  })
};

//Run Commands

//Here is where we actually start 
//off the whole process.
getInput();